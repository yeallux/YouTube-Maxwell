const button = document.getElementById("toggle");

function updateButton(enabled) {
    button.textContent = enabled ? "Disable" : "Enable";
}

chrome.storage.local.get("enabled", (data) => {
    updateButton(data.enabled ?? true);
});


button.onclick = () => {
    chrome.storage.local.get("enabled", (data) => {
        let enabled = !(data.enabled ?? true);

        chrome.storage.local.set({
            enabled: enabled
        });

        updateButton(enabled);
    });
};