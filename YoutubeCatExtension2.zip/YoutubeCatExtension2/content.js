let enabled = true;

chrome.storage.local.get("enabled", (data) => {
    enabled = data.enabled ?? true;

    if (enabled) {
        replaceEverything();
    }
});


chrome.storage.onChanged.addListener((changes) => {
    if (changes.enabled) {
        enabled = changes.enabled.newValue;

        if (enabled) {
            replaceEverything();
        } else {
            location.reload();
        }
    }
});

const thumbnail = chrome.runtime.getURL("Maxwell.png");

function replaceEverything() {
    if (!enabled) return;
    document.querySelectorAll("img").forEach(img => {
        if (img.src.includes("i.ytimg.com")) {
            img.src = thumbnail;
            img.srcset = "";
        }
    });

    // Replace titles
    document.querySelectorAll(".ytLockupMetadataViewModelTitle").forEach(title => {
        title.textContent = "You've Been Maxwellm'd !";
    });
}

// Initial run
replaceEverything();

let timeout;

const observer = new MutationObserver(() => {
    clearTimeout(timeout);
    timeout = setTimeout(() => {
        replaceEverything();
    }, 100);
});

observer.observe(document.body, {
    childList: true,
    subtree: true
});